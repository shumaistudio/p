// プレイヤーと同じような行動の実装
const { goals } = require('mineflayer-pathfinder');
const { Vec3 } = require('vec3');
const { sleep } = require('./util');

class Cancelled extends Error {}

class Actions {
  constructor(agent) {
    this.agent = agent;
    this.bot = agent.bot;
    this.ctx = { cancelled: false };
    this.handlers = {
      goto: this.goto, goto_entity: this.gotoEntity, explore: this.explore, collect: this.collect,
      craft: this.craft, smelt: this.smelt, place: this.place, equip: this.equip, eat: this.eat,
      sleep: this.sleepBed, attack: this.attack, give: this.give, say: this.say, wait: this.wait,
    };
  }

  async run(act, ctx) {
    this.ctx = ctx;
    try { return await this.handlers[act.type].call(this, act.args || {}); }
    catch (e) {
      if (ctx.cancelled || e instanceof Cancelled) return '中断された';
      return `失敗: ${e.message}`;
    }
  }

  check() { if (this.ctx.cancelled) throw new Cancelled(); }

  async go(goal, timeout = 60000) {
    this.check();
    const p = this.bot.pathfinder.goto(goal);
    const timer = setTimeout(() => this.bot.pathfinder.stop(), timeout);
    try { await p; } finally { clearTimeout(timer); }
    this.check();
  }

  findEntity(name) {
    const bot = this.bot;
    const pl = bot.players[name];
    if (pl && pl.entity) return pl.entity;
    const p = bot.entity.position;
    return Object.values(bot.entities)
      .filter((e) => e !== bot.entity && (e.name === name || e.username === name))
      .sort((a, b) => a.position.distanceTo(p) - b.position.distanceTo(p))[0];
  }

  // ---- 移動 ----
  async goto({ x, y, z }) {
    if ([x, y, z].some((v) => typeof v !== 'number')) throw new Error('座標が不正');
    await this.go(new goals.GoalNear(x, y, z, 1));
    return `(${x},${y},${z})に着いた`;
  }

  async gotoEntity({ name }) {
    const e = this.findEntity(name);
    if (!e) throw new Error(`${name}が視界内にいない`);
    await this.go(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 2));
    return `${name}の近くに来た`;
  }

  async explore({ distance = 30 }) {
    const d = Math.min(Math.max(Number(distance) || 30, 10), 60);
    const a = Math.random() * Math.PI * 2;
    const p = this.bot.entity.position;
    await this.go(new goals.GoalXZ(Math.floor(p.x + Math.cos(a) * d), Math.floor(p.z + Math.sin(a) * d)), 45000);
    return '探索した';
  }

  // ---- 採取 ----
  async pickupDrops() {
    const bot = this.bot;
    const items = Object.values(bot.entities)
      .filter((e) => e.name === 'item' && e.position.distanceTo(bot.entity.position) < 8)
      .slice(0, 5);
    for (const e of items) {
      this.check();
      try { await this.go(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 0.5), 8000); }
      catch (err) { if (err instanceof Cancelled) throw err; }
    }
  }

  async collect({ block, count = 1 }) {
    const bot = this.bot;
    const def = bot.registry.blocksByName[block];
    if (!def) throw new Error(`不明なブロック: ${block}`);
    const target = Math.min(Number(count) || 1, 32);
    let got = 0, fails = 0;
    while (got < target) {
      this.check();
      const b = bot.findBlock({ matching: def.id, maxDistance: 48 });
      if (!b) { if (!got) throw new Error(`近くに${block}が見つからない`); break; }
      try {
        await this.go(new goals.GoalGetToBlock(b.position.x, b.position.y, b.position.z));
        await bot.tool.equipForBlock(b);
        if (!b.canHarvest(bot.heldItem ? bot.heldItem.type : null)) throw new Error('適切な道具がない');
        await bot.dig(b);
        got++;
        await this.pickupDrops();
      } catch (e) {
        if (this.ctx.cancelled || e instanceof Cancelled) throw new Cancelled();
        if (e.message === '適切な道具がない' || ++fails >= 3) throw e;
      }
    }
    return `${block}を${got}個掘った`;
  }

  // ---- 設置 ----
  async placeBlockAt(itemName, target) {
    const bot = this.bot;
    const item = bot.inventory.items().find((i) => i.name === itemName);
    if (!item) throw new Error(`${itemName}を持っていない`);
    const cur = bot.blockAt(target);
    if (cur && !['air', 'cave_air', 'void_air'].includes(cur.name)) throw new Error('そこは空いていない');
    for (const d of [[0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0]]) {
      const ref = bot.blockAt(target.offset(...d));
      if (ref && ref.boundingBox === 'block') {
        await bot.equip(item, 'hand');
        await bot.lookAt(ref.position.offset(0.5, 0.5, 0.5));
        await bot.placeBlock(ref, new Vec3(-d[0], -d[1], -d[2]));
        await sleep(250);
        return bot.blockAt(target);
      }
    }
    throw new Error('置くための足場がない');
  }

  async placeNear(itemName) {
    const bot = this.bot;
    const base = bot.entity.position.floored();
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1]]) {
      const t = base.offset(dx, 0, dz);
      const cur = bot.blockAt(t), below = bot.blockAt(t.offset(0, -1, 0));
      if (cur && cur.name === 'air' && below && below.boundingBox === 'block') {
        try { return await this.placeBlockAt(itemName, t); } catch {}
      }
    }
    throw new Error(`${itemName}を置ける場所がない`);
  }

  async place({ block, x, y, z }) {
    if ([x, y, z].some((v) => typeof v !== 'number')) throw new Error('座標が不正');
    await this.go(new goals.GoalNear(x, y, z, 3));
    await this.placeBlockAt(block, new Vec3(Math.floor(x), Math.floor(y), Math.floor(z)));
    return `${block}を(${x},${y},${z})に置いた`;
  }

  // ---- クラフト・精錬 ----
  async craft({ item, count = 1 }) {
    const bot = this.bot;
    const it = bot.registry.itemsByName[item];
    if (!it) throw new Error(`不明なアイテム: ${item}`);
    const n = Math.min(Number(count) || 1, 16);
    let table = null;
    let recipes = bot.recipesFor(it.id, null, 1, null);
    if (!recipes.length) {
      const tid = bot.registry.blocksByName.crafting_table.id;
      table = bot.findBlock({ matching: tid, maxDistance: 32 });
      if (!table && bot.inventory.items().some((i) => i.name === 'crafting_table')) table = await this.placeNear('crafting_table');
      if (!table) throw new Error('作業台が必要(または材料不足)');
      await this.go(new goals.GoalNear(table.position.x, table.position.y, table.position.z, 2));
      recipes = bot.recipesFor(it.id, null, 1, table);
    }
    if (!recipes.length) throw new Error(`材料不足か未知のレシピ: ${item}`);
    await bot.craft(recipes[0], n, table);
    return `${item}を${n}回クラフトした`;
  }

  async smelt({ item, count = 1 }) {
    const bot = this.bot;
    const n = Math.min(Number(count) || 1, 32);
    const input = bot.inventory.items().find((i) => i.name === item);
    if (!input) throw new Error(`${item}を持っていない`);
    const fuelNames = ['coal', 'charcoal', 'oak_planks', 'spruce_planks', 'birch_planks', 'oak_log', 'spruce_log', 'birch_log'];
    const fuel = fuelNames.map((nm) => bot.inventory.items().find((i) => i.name === nm)).find(Boolean);
    if (!fuel) throw new Error('燃料がない');

    const fid = bot.registry.blocksByName.furnace.id;
    let block = bot.findBlock({ matching: fid, maxDistance: 32 });
    if (!block && bot.inventory.items().some((i) => i.name === 'furnace')) block = await this.placeNear('furnace');
    if (!block) throw new Error('かまどがない');
    await this.go(new goals.GoalNear(block.position.x, block.position.y, block.position.z, 2));

    const furnace = await bot.openFurnace(block);
    try {
      const need = /coal|charcoal/.test(fuel.name) ? Math.ceil(n / 8) : Math.ceil(n / 1.5);
      await furnace.putFuel(fuel.type, null, Math.min(fuel.count, need));
      await furnace.putInput(input.type, null, Math.min(input.count, n));
      const t0 = Date.now();
      while (Date.now() - t0 < n * 10000 + 5000) {
        this.check();
        const out = furnace.outputItem();
        if (out && out.count >= Math.min(input.count, n)) break;
        await sleep(2000);
      }
      const out = furnace.outputItem();
      if (out) await furnace.takeOutput();
      return `${item}を精錬して${out ? out.count : 0}個取り出した`;
    } finally { furnace.close(); }
  }

  // ---- 身の回り ----
  async equip({ item }) {
    const bot = this.bot;
    const it = bot.inventory.items().find((i) => i.name === item);
    if (!it) throw new Error(`${item}を持っていない`);
    let dest = 'hand';
    if (item.endsWith('_helmet')) dest = 'head';
    else if (item.endsWith('_chestplate')) dest = 'torso';
    else if (item.endsWith('_leggings')) dest = 'legs';
    else if (item.endsWith('_boots')) dest = 'feet';
    else if (item === 'shield') dest = 'off-hand';
    await bot.equip(it, dest);
    return `${item}を装備した`;
  }

  async eat() {
    await this.agent.reflex.eat();
    return '食事した';
  }

  async sleepBed() {
    const bot = this.bot;
    const bed = bot.findBlock({ matching: (b) => b.name.endsWith('_bed'), maxDistance: 32 });
    if (!bed) throw new Error('近くにベッドがない');
    await this.go(new goals.GoalNear(bed.position.x, bed.position.y, bed.position.z, 2));
    await bot.sleep(bed);
    const t0 = Date.now();
    while (bot.isSleeping && Date.now() - t0 < 120000) { this.check(); await sleep(1000); }
    return '眠った';
  }

  async attack({ target = 'hostile' }) {
    const bot = this.bot;
    const p = bot.entity.position;
    const e = target === 'hostile'
      ? this.agent.reflex.hostiles(24)[0]
      : this.findEntity(target);
    if (!e) throw new Error(`対象が見つからない: ${target}`);
    const r = await this.agent.reflex.fight(e, { timeout: 25000, stop: () => this.ctx.cancelled });
    this.check();
    await this.pickupDrops();
    return `${e.name}との戦闘: ${r}`;
  }

  // ---- 協力 ----
  async give({ item, count = 1, to }) {
    const bot = this.bot;
    const it = bot.inventory.items().find((i) => i.name === item);
    if (!it) throw new Error(`${item}を持っていない`);
    const e = this.findEntity(to);
    if (!e) throw new Error(`${to}が視界内にいない`);
    await this.go(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 2));
    await bot.lookAt(e.position.offset(0, e.height * 0.8, 0));
    const n = Math.min(Number(count) || 1, it.count);
    await bot.toss(it.type, null, n);
    return `${to}に${item}を${n}個渡した`;
  }

  async say({ message }) {
    if (!message) throw new Error('メッセージが空');
    const m = String(message).slice(0, 200);
    this.bot.chat(m);
    this.agent.memory.pushEvent(`自分の発言「${m}」`);
    await sleep(1200);
    return '発言した';
  }

  async wait({ seconds = 3 }) {
    const end = Date.now() + Math.min(Number(seconds) || 3, 30) * 1000;
    while (Date.now() < end) { this.check(); await sleep(300); }
    return '待機した';
  }
}

module.exports = { Actions };
