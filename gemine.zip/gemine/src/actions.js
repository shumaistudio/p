// プレイヤーと同じような行動の実装
const { goals } = require('mineflayer-pathfinder');
const { Vec3 } = require('vec3');
const { sleep } = require('./util');

class Cancelled extends Error {}

class Actions {
  constructor(agent) {
    this.agent = agent;
    this.bot = agent.bot;
    this.ctx = { cancelled: false };
    this.handlers = {
      goto: this.goto, goto_entity: this.gotoEntity, explore: this.explore, collect: this.collect,
      craft: this.craft, smelt: this.smelt, place: this.place, equip: this.equip, eat: this.eat,
      sleep: this.sleepBed, attack: this.attack, give: this.give, say: this.say, wait: this.wait,
    };
  }

  async run(act, ctx) {
    this.ctx = ctx;
    try { return await this.handlers[act.type].call(this, act.args || {}); }
    catch (e) {
      if (ctx.cancelled || e instanceof Cancelled) return '中断された';
      return `失敗: ${e.message}`;
    }
  }

  check() { if (this.ctx.cancelled) throw new Cancelled(); }

  async go(goal, timeout = 60000) {
    this.check();
    const p = this.bot.pathfinder.goto(goal);
    const timer = setTimeout(() => this.bot.pathfinder.stop(), timeout);
    try { await p; } finally { clearTimeout(timer); }
    this.check();
  }

  findEntity(name) {
    const bot = this.bot;
    const pl = bot.players[name];
    if (pl && pl.entity) return pl.entity;
    const p = bot.entity.position;
    return Object.values(bot.entities)
      .filter((e) => e !== bot.entity && (e.name === name || e.username === name))
      .sort((a, b) => a.position.distanceTo(p) - b.position.distanceTo(p))[0];
  }

  // ---- 移動 ----
  async goto({ x, y, z }) {
    if ([x, y, z].some((v) => typeof v !== 'number')) throw new Error('座標が不正');
    await this.go(new goals.GoalNear(x, y, z, 1));
    return `(${x},${y},${z})に着いた`;
  }

  async gotoEntity({ name }) {
    const e = this.findEntity(name);
    if (!e) throw new Error(`${name}が視界内にいない`);
    await this.go(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 2));
    return `${name}の近くに来た`;
  }

  async explore({ distance = 30 }) {
    const d = Math.min(Math.max(Number(distance) || 30, 10), 60);
    const a = Math.random() * Math.PI * 2;
    const p = this.bot.entity.position;
    await this.go(new goals.GoalXZ(Math.floor(p.x + Math.cos(a) * d), Math.floor(p.z + Math.sin(a) * d)), 45000);
    return '探索した';
  }

  // ---- 採取 ----
  async pickupDrops() {
    const bot = this.bot;
    const items = Object.values(bot.entities)
      .filter((e) => e.name === 'item' && e.position.distanceTo(bot.entity.position) < 8)
      .slice(0, 5);
    for (const e of items) {
      this.check();
      try { await this.go(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 0.5), 8000); }
      catch (err) { if (err instanceof Cancelled) throw err; }
    }
  }

  // 1個のブロックを確実に掘る(届かなければ近づき直し、失敗したら再試行)
  async mineBlock(b) {
    const bot = this.bot;
    for (let i = 0; i < 3; i++) {
      this.check();
      const cur = bot.blockAt(b.position);
      if (!cur || cur.name === 'air') return;
      const center = cur.position.offset(0.5, 0.5, 0.5);
      if (!bot.canDigBlock(cur) || bot.entity.position.distanceTo(center) > 4.5) {
        await this.go(new goals.GoalNear(cur.position.x, cur.position.y, cur.position.z, 3), 15000);
      }
      await bot.tool.equipForBlock(cur);
      if (!cur.canHarvest(bot.heldItem ? bot.heldItem.type : null)) throw new Error('適切な道具がない');
      try { await bot.dig(cur, true); }
      catch (e) { if (this.ctx.cancelled) throw new Cancelled(); await sleep(300); continue; }
      return;
    }
    throw new Error('掘れなかった');
  }

  async collect({ block, count = 1 }) {
    const bot = this.bot;
    const def = bot.registry.blocksByName[block];
    if (!def) throw new Error(`不明なブロック: ${block}`);
    const target = Math.min(Number(count) || 1, 32);
    const skip = new Set(); // 掘れなかったブロックは除外して次へ
    let got = 0, fails = 0;
    while (got < target) {
      this.check();
      const b = bot.findBlock({
        matching: (x) => x && x.type === def.id && !skip.has(String(x.position)),
        maxDistance: 48,
      });
      if (!b) { if (!got) throw new Error(`近くに${block}が見つからない`); break; }
      try {
        await this.go(new goals.GoalGetToBlock(b.position.x, b.position.y, b.position.z));
        await this.mineBlock(b);
        got++; fails = 0;
        await this.pickupDrops();
      } catch (e) {
        if (this.ctx.cancelled || e instanceof Cancelled) throw new Cancelled();
        if (e.message === '適切な道具がない') throw e;
        skip.add(String(b.position));
        if (++fails >= 4) throw e;
      }
    }
    return `${block}を${got}個掘った`;
  }

  // ---- 設置 ----
  async placeBlockAt(itemName, target) {
    const bot = this.bot;
    const item = bot.inventory.items().find((i) => i.name === itemName);
    if (!item) throw new Error(`${itemName}を持っていない`);
    const cur = bot.blockAt(target);
    if (cur && !['air', 'cave_air', 'void_air'].includes(cur.name)) throw new Error('そこは空いていない');
    for (const d of [[0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0]]) {
      const ref = bot.blockAt(target.offset(...d));
      if (ref && ref.boundingBox === 'block') {
        await bot.equip(item, 'hand');
        await bot.lookAt(ref.position.offset(0.5, 0.5, 0.5));
        await bot.placeBlock(ref, new Vec3(-d[0], -d[1], -d[2]));
        await sleep(250);
        return bot.blockAt(target);
      }
    }
    throw new Error('置くための足場がない');
  }

  async placeNear(itemName) {
    const bot = this.bot;
    const base = bot.entity.position.floored();
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1]]) {
      const t = base.offset(dx, 0, dz);
      const cur = bot.blockAt(t), below = bot.blockAt(t.offset(0, -1, 0));
      if (cur && cur.name === 'air' && below && below.boundingBox === 'block') {
        try { return await this.placeBlockAt(itemName, t); } catch {}
      }
    }
    throw new Error(`${itemName}を置ける場所がない`);
  }

  async place({ block, x, y, z }) {
    if ([x, y, z].some((v) => typeof v !== 'number')) throw new Error('座標が不正');
    await this.go(new goals.GoalNear(x, y, z, 3));
    await this.placeBlockAt(block, new Vec3(Math.floor(x), Math.floor(y), Math.floor(z)));
    return `${block}を(${x},${y},${z})に置いた`;
  }

  // ---- クラフト・精錬 ----
  // 作業台を確保する: 近くにあればそれ / 持っていれば設置 / 無ければ材料から作って設置
  async ensureTable() {
    const bot = this.bot;
    const tid = bot.registry.blocksByName.crafting_table.id;
    const found = bot.findBlock({ matching: tid, maxDistance: 48 });
    if (found) return found;

    if (!bot.inventory.items().some((i) => i.name === 'crafting_table')) {
      const planks = () => bot.inventory.items().filter((i) => i.name.endsWith('_planks')).reduce((n, i) => n + i.count, 0);
      if (planks() < 4) {
        const log = bot.inventory.items().find((i) => /_(log|stem)$/.test(i.name)
          && bot.registry.itemsByName[i.name.replace(/_(log|stem)$/, '_planks')]);
        if (!log) throw new Error('作業台がなく、作る材料(原木・板材)もない');
        const pid = bot.registry.itemsByName[log.name.replace(/_(log|stem)$/, '_planks')].id;
        const pr = bot.recipesFor(pid, null, 1, null);
        if (!pr.length) throw new Error('板材を作れない');
        await bot.craft(pr[0], 1, null);
      }
      const tr = bot.recipesFor(bot.registry.itemsByName.crafting_table.id, null, 1, null);
      if (!tr.length) throw new Error('作業台の材料(板材4枚)が足りない');
      await bot.craft(tr[0], 1, null);
      this.agent.memory.pushEvent('作業台を自作した');
    }
    const placed = await this.placeNear('crafting_table');
    const p = placed.position;
    this.agent.memory.pushEvent(`作業台を設置した (x${p.x} y${p.y} z${p.z})`);
    this.agent.memory.add(`作業台を x${p.x} y${p.y} z${p.z} に設置した`, 5);
    return placed;
  }

  async craft({ item, count = 1 }) {
    const bot = this.bot;
    const it = bot.registry.itemsByName[item];
    if (!it) throw new Error(`不明なアイテム: ${item}`);
    const n = Math.min(Number(count) || 1, 16);
    let table = null;
    let recipes = bot.recipesFor(it.id, null, 1, null);
    if (!recipes.length) {
      // 作業台があれば作れるか? (true = 作業台ありとして判定)
      if (!bot.recipesFor(it.id, null, 1, true).length) throw new Error(`材料不足か未知のレシピ: ${item}`);
      table = await this.ensureTable();
      await this.go(new goals.GoalNear(table.position.x, table.position.y, table.position.z, 2));
      recipes = bot.recipesFor(it.id, null, 1, table);
      if (!recipes.length) throw new Error(`材料不足: ${item}(作業台の設置で材料を使った可能性)`);
    }
    await bot.craft(recipes[0], n, table);
    return `${item}を${n}回クラフトした`;
  }

  async smelt({ item, count = 1 }) {
    const bot = this.bot;
    const n = Math.min(Number(count) || 1, 32);
    const input = bot.inventory.items().find((i) => i.name === item);
    if (!input) throw new Error(`${item}を持っていない`);
    const fuelNames = ['coal', 'charcoal', 'oak_planks', 'spruce_planks', 'birch_planks', 'oak_log', 'spruce_log', 'birch_log'];
    const fuel = fuelNames.map((nm) => bot.inventory.items().find((i) => i.name === nm)).find(Boolean);
    if (!fuel) throw new Error('燃料がない');

    const fid = bot.registry.blocksByName.furnace.id;
    let block = bot.findBlock({ matching: fid, maxDistance: 32 });
    if (!block && bot.inventory.items().some((i) => i.name === 'furnace')) block = await this.placeNear('furnace');
    if (!block) throw new Error('かまどがない');
    await this.go(new goals.GoalNear(block.position.x, block.position.y, block.position.z, 2));

    const furnace = await bot.openFurnace(block);
    try {
      const need = /coal|charcoal/.test(fuel.name) ? Math.ceil(n / 8) : Math.ceil(n / 1.5);
      await furnace.putFuel(fuel.type, null, Math.min(fuel.count, need));
      await furnace.putInput(input.type, null, Math.min(input.count, n));
      const t0 = Date.now();
      while (Date.now() - t0 < n * 10000 + 5000) {
        this.check();
        const out = furnace.outputItem();
        if (out && out.count >= Math.min(input.count, n)) break;
        await sleep(2000);
      }
      const out = furnace.outputItem();
      if (out) await furnace.takeOutput();
      return `${item}を精錬して${out ? out.count : 0}個取り出した`;
    } finally { furnace.close(); }
  }

  // ---- 身の回り ----
  async equip({ item }) {
    const bot = this.bot;
    const it = bot.inventory.items().find((i) => i.name === item);
    if (!it) throw new Error(`${item}を持っていない`);
    let dest = 'hand';
    if (item.endsWith('_helmet')) dest = 'head';
    else if (item.endsWith('_chestplate')) dest = 'torso';
    else if (item.endsWith('_leggings')) dest = 'legs';
    else if (item.endsWith('_boots')) dest = 'feet';
    else if (item === 'shield') dest = 'off-hand';
    await bot.equip(it, dest);
    return `${item}を装備した`;
  }

  async eat() {
    await this.agent.reflex.eat();
    return '食事した';
  }

  async sleepBed() {
    const bot = this.bot;
    const bed = bot.findBlock({ matching: (b) => b.name.endsWith('_bed'), maxDistance: 32 });
    if (!bed) throw new Error('近くにベッドがない');
    await this.go(new goals.GoalNear(bed.position.x, bed.position.y, bed.position.z, 2));
    await bot.sleep(bed);
    const t0 = Date.now();
    while (bot.isSleeping && Date.now() - t0 < 120000) { this.check(); await sleep(1000); }
    return '眠った';
  }

  async attack({ target = 'hostile' }) {
    const bot = this.bot;
    if (this.agent.partners.includes(target)) throw new Error('仲間は攻撃できない');
    const e = target === 'hostile'
      ? this.agent.reflex.hostiles(24)[0]
      : this.findEntity(target);
    if (!e) throw new Error(`対象が見つからない: ${target}`);
    const r = await this.agent.reflex.fight(e, { timeout: 25000, stop: () => this.ctx.cancelled });
    this.check();
    await this.pickupDrops();
    return `${e.name}との戦闘: ${r}`;
  }

  // ---- 協力 ----
  async give({ item, count = 1, to }) {
    const bot = this.bot;
    const it = bot.inventory.items().find((i) => i.name === item);
    if (!it) throw new Error(`${item}を持っていない`);
    const e = this.findEntity(to);
    if (!e) throw new Error(`${to}が視界内にいない`);
    await this.go(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 2));
    await bot.lookAt(e.position.offset(0, e.height * 0.8, 0));
    const n = Math.min(Number(count) || 1, it.count);
    await bot.toss(it.type, null, n);
    return `${to}に${item}を${n}個渡した`;
  }

  async say({ message }) {
    if (!message) throw new Error('メッセージが空');
    const m = String(message).slice(0, 200);
    this.bot.chat(m);
    this.agent.memory.pushEvent(`自分の発言「${m}」`);
    await sleep(1200);
    return '発言した';
  }

  async wait({ seconds = 3 }) {
    const end = Date.now() + Math.min(Number(seconds) || 3, 30) * 1000;
    while (Date.now() < end) { this.check(); await sleep(300); }
    return '待機した';
  }
}

module.exports = { Actions };
