const fs = require('fs');
const path = require('path');
const { clamp } = require('./util');

const DATA_DIR = path.join(__dirname, '..', 'data');

class Memory {
  constructor(cfg, partnerNames) {
    this.file = path.join(DATA_DIR, `${cfg.name}.json`);
    this.events = []; // 短期記憶(直近の出来事)
    fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(this.file)) {
      this.data = JSON.parse(fs.readFileSync(this.file, 'utf8'));
    } else {
      const now = Date.now();
      this.data = {
        mood: '普通',
        goal: cfg.initialGoal,
        affinity: Object.fromEntries(partnerNames.map((n) => [n, cfg.initialAffinity])),
        longTerm: cfg.initialMemories.map((m) => ({ ...m, t: now })),
      };
      this.save();
    }
  }

  save() {
    try { fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2)); } catch {}
  }

  pushEvent(text) {
    this.events.push({ t: Date.now(), text: String(text).slice(0, 200) });
    if (this.events.length > 30) this.events.shift();
  }

  // 重要度が高いほど忘れにくい(半減期 = 重要度×2時間)
  score(m) {
    const hours = (Date.now() - m.t) / 3.6e6;
    return m.importance * Math.pow(0.5, hours / (m.importance * 2));
  }

  add(text, importance = 5) {
    if (!text) return;
    text = String(text).slice(0, 150);
    const imp = clamp(Math.round(Number(importance) || 5), 1, 10);
    const dup = this.data.longTerm.find((m) => m.text === text);
    if (dup) { dup.t = Date.now(); dup.importance = Math.max(dup.importance, imp); }
    else this.data.longTerm.push({ text, importance: imp, t: Date.now() });
    if (this.data.longTerm.length > 80) {
      this.data.longTerm.sort((a, b) => this.score(b) - this.score(a));
      this.data.longTerm = this.data.longTerm.slice(0, 60); // 忘却
    }
    this.save();
  }

  recall(n = 12) {
    return [...this.data.longTerm]
      .map((m) => ({ m, s: this.score(m) }))
      .filter((x) => x.s > 0.5)
      .sort((a, b) => b.s - a.s)
      .slice(0, n)
      .map((x) => x.m.text);
  }

  adjustAffinity(name, delta) {
    if (!(name in this.data.affinity) || !Number.isFinite(delta)) return;
    this.data.affinity[name] = clamp(this.data.affinity[name] + clamp(delta, -10, 10), 0, 100);
    this.save();
  }

  affinityLabel(v) {
    if (v < 20) return '嫌い・警戒している';
    if (v < 40) return '少し苦手';
    if (v < 60) return '普通・まだよく知らない';
    if (v < 80) return '好意的・信頼している';
    return '大切な親友';
  }

  recentEvents() {
    const now = Date.now();
    return this.events.slice(-15).map((e) => `${Math.round((now - e.t) / 1000)}秒前: ${e.text}`);
  }
}

module.exports = { Memory };
