// botの現在の状況をGeminiに渡すためのテキスト化
const CATEGORIES = {
  '原木': (b) => b.name.endsWith('_log'),
  '石': (b) => b.name === 'stone',
  '石炭鉱石': (b) => b.name.includes('coal_ore'),
  '鉄鉱石': (b) => b.name.includes('iron_ore'),
  'ダイヤ鉱石': (b) => b.name.includes('diamond_ore'),
  '水': (b) => b.name === 'water',
  '溶岩': (b) => b.name === 'lava',
  '作業台': (b) => b.name === 'crafting_table',
  'かまど': (b) => b.name === 'furnace',
  'ベッド': (b) => b.name.endsWith('_bed'),
  'チェスト': (b) => b.name === 'chest',
  '砂': (b) => b.name === 'sand',
};

const f = (v) => Math.floor(v);

function observe(agent) {
  const bot = agent.bot;
  const p = bot.entity.position;

  const inventory = {};
  for (const i of bot.inventory.items()) inventory[i.name] = (inventory[i.name] || 0) + i.count;

  const entities = Object.values(bot.entities)
    .filter((e) => e !== bot.entity && e.position && e.position.distanceTo(p) < 24)
    .sort((a, b) => a.position.distanceTo(p) - b.position.distanceTo(p))
    .slice(0, 12)
    .map((e) => `${e.username || e.name}(${f(e.position.distanceTo(p))}m, x${f(e.position.x)} y${f(e.position.y)} z${f(e.position.z)})`);

  const nearbyBlocks = {};
  for (const [label, fn] of Object.entries(CATEGORIES)) {
    try {
      const found = bot.findBlocks({ matching: (b) => b && fn(b), maxDistance: 24, count: 1 });
      if (found.length) {
        const q = found[0];
        nearbyBlocks[label] = `最寄り x${q.x} y${q.y} z${q.z}`;
      }
    } catch {}
  }

  const partners = agent.partners.map((n) => {
    const pl = bot.players[n];
    if (!pl) return `${n}: オフライン`;
    if (!pl.entity) return `${n}: オンライン(視界外。座標は不明)`;
    const q = pl.entity.position;
    return `${n}: 視界内 x${f(q.x)} y${f(q.y)} z${f(q.z)}`;
  });

  const t = bot.time.timeOfDay;
  return {
    位置: `x${f(p.x)} y${f(p.y)} z${f(p.z)}`,
    体力: `${Math.round(bot.health)}/20`,
    満腹度: `${bot.food}/20`,
    時間帯: t < 12000 ? '昼' : t < 13800 ? '夕方' : t < 23000 ? '夜(モンスターが出る)' : '明け方',
    天気: bot.isRaining ? '雨' : '晴れ',
    手持ち: bot.heldItem ? bot.heldItem.name : 'なし',
    持ち物: inventory,
    付近のブロック: nearbyBlocks,
    付近のエンティティ: entities,
    仲間: partners,
  };
}

module.exports = { observe };
