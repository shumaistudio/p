const config = require('./config');
const { Agent } = require('./agent');
const { sleep, log } = require('./util');

(async () => {
  log('gemine', `server=${config.server.host}:${config.server.port} v${config.server.version}`);
  log('gemine', `model: ${config.models.primary} (上限到達時 → ${config.models.fallback})`);
  for (const cfg of config.bots) {
    new Agent(cfg, config).connect();
    await sleep(3000); // ログイン間隔をずらす
  }
})();

process.on('unhandledRejection', (e) => console.error('unhandledRejection:', e && e.message ? e.message : e));
