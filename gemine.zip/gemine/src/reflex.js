// 反射行動: Geminiを介さず即座に動く。終わった後に推論を要求する。
const { goals } = require('mineflayer-pathfinder');
const { sleep } = require('./util');

const HOSTILE = new Set([
  'zombie', 'zombie_villager', 'husk', 'drowned', 'skeleton', 'stray', 'bogged',
  'spider', 'cave_spider', 'creeper', 'witch', 'pillager', 'vindicator', 'slime',
  'phantom', 'silverfish', 'blaze', 'wither_skeleton',
]);
const TIER = ['netherite', 'diamond', 'iron', 'stone', 'golden', 'wooden'];
const BAD_FOOD = new Set(['rotten_flesh', 'spider_eye', 'pufferfish', 'poisonous_potato', 'chorus_fruit']);
const ARMOR = { _helmet: [5, 'head'], _chestplate: [6, 'torso'], _leggings: [7, 'legs'], _boots: [8, 'feet'] };

class Reflex {
  constructor(agent) {
    this.agent = agent;
    this.bot = agent.bot;
    this.active = false;   // 反射行動の実行中
    this.fighting = false; // 戦闘中(行動としての攻撃も含む)
    this.lastEat = 0;
    this.lastArmor = 0;
    this.timer = setInterval(() => this.check().catch(() => {}), 250);
  }

  stop() { clearInterval(this.timer); }

  hostiles(maxDist) {
    const p = this.bot.entity.position;
    return Object.values(this.bot.entities)
      .filter((e) => e.name && HOSTILE.has(e.name) && e.position.distanceTo(p) <= maxDist)
      .sort((a, b) => a.position.distanceTo(p) - b.position.distanceTo(p));
  }

  async trigger(label, fn, interrupt = true) {
    this.active = true;
    this.agent.epoch++;
    if (interrupt) this.agent.interrupt(true);
    try { await fn(); } catch {}
    finally {
      this.bot.clearControlStates();
      try { this.bot.pathfinder.setGoal(null); } catch {}
      this.active = false;
      this.agent.memory.pushEvent(`【反射】${label} (体力${Math.round(this.bot.health)} 満腹${this.bot.food})`);
      this.agent.thinkRequested = true;
    }
  }

  async check() {
    const bot = this.bot;
    if (!bot.entity || bot.health <= 0 || this.active || this.fighting) return;
    const feet = bot.blockAt(bot.entity.position);

    // 1. 溶岩
    if (feet && feet.name === 'lava') return this.trigger('溶岩から脱出した', () => this.escapeLava());
    // 2. 溺れ
    if (feet && feet.name === 'water' && bot.oxygenLevel !== undefined && bot.oxygenLevel <= 8)
      return this.trigger('溺れそうで浮上した', () => this.surface());
    // 3. クリーパー
    const creeper = this.hostiles(6).find((e) => e.name === 'creeper');
    if (creeper) return this.trigger('クリーパーから逃げた', () => this.flee(creeper, 8000));
    // 4. 敵モブ
    const hostile = this.hostiles(5)[0];
    if (hostile) {
      if (bot.health <= 6) return this.trigger(`${hostile.name}から逃げた(体力低下)`, () => this.flee(hostile, 6000));
      return this.trigger(`${hostile.name}と戦った`, () => this.fight(hostile, { timeout: 15000 }));
    }
    // 5. 空腹
    if (bot.food <= 12 && Date.now() - this.lastEat > 5000) {
      this.lastEat = Date.now();
      if (this.findFood(bot.food <= 6)) return this.trigger('食事をした', () => this.eat());
    }
    // 6. 防具の自動装備(5秒ごと)
    if (Date.now() - this.lastArmor > 5000) { this.lastArmor = Date.now(); await this.autoArmor(); }
  }

  async escapeLava() {
    const bot = this.bot;
    await bot.look(Math.random() * Math.PI * 2, 0, true);
    bot.setControlState('jump', true); bot.setControlState('sprint', true); bot.setControlState('forward', true);
    await sleep(2500);
  }

  async surface() {
    const bot = this.bot;
    bot.setControlState('jump', true);
    const t0 = Date.now();
    while (Date.now() - t0 < 6000 && (bot.oxygenLevel ?? 20) < 18) await sleep(200);
  }

  async flee(threat, ms) {
    const bot = this.bot;
    bot.pathfinder.setGoal(new goals.GoalInvert(new goals.GoalFollow(threat, 12)), true);
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      await sleep(300);
      if (!threat.isValid || threat.position.distanceTo(bot.entity.position) > 14) break;
    }
    bot.pathfinder.setGoal(null);
  }

  weaponRank(item) {
    const idx = TIER.findIndex((t) => item.name.startsWith(t + '_'));
    if (idx < 0) return -1;
    return (item.name.endsWith('_sword') ? 20 : item.name.endsWith('_axe') ? 10 : 0) + (10 - idx);
  }

  async fight(target, { timeout = 20000, stop = () => false } = {}) {
    const bot = this.bot;
    this.fighting = true;
    try {
      const w = bot.inventory.items().filter((i) => this.weaponRank(i) >= 0).sort((a, b) => this.weaponRank(b) - this.weaponRank(a))[0];
      if (w) await bot.equip(w, 'hand').catch(() => {});
      const t0 = Date.now();
      while (target.isValid && Date.now() - t0 < timeout && !stop()) {
        if (bot.health <= 6) return 'low_hp';
        const d = bot.entity.position.distanceTo(target.position);
        if (d > 3) {
          bot.pathfinder.setGoal(new goals.GoalFollow(target, 2), true);
          await sleep(200);
        } else {
          bot.pathfinder.setGoal(null);
          await bot.lookAt(target.position.offset(0, target.height * 0.8, 0));
          bot.attack(target);
          await sleep(600);
        }
      }
      return target.isValid ? 'timeout' : 'killed';
    } finally {
      bot.pathfinder.setGoal(null);
      this.fighting = false;
    }
  }

  findFood(allowBad = false) {
    const reg = this.bot.registry.foodsByName;
    return this.bot.inventory.items()
      .filter((i) => reg[i.name] && (allowBad || !BAD_FOOD.has(i.name)))
      .sort((a, b) => reg[b.name].foodPoints - reg[a.name].foodPoints)[0];
  }

  async eat() {
    const food = this.findFood(this.bot.food <= 6);
    if (!food) throw new Error('食べ物がない');
    await this.bot.equip(food, 'hand');
    await this.bot.consume();
  }

  async autoArmor() {
    const bot = this.bot;
    for (const item of bot.inventory.items()) {
      for (const [suffix, [slot, dest]] of Object.entries(ARMOR)) {
        if (item.name.endsWith(suffix) && !bot.inventory.slots[slot]) {
          try { await bot.equip(item, dest); this.agent.memory.pushEvent(`${item.name}を装備した`); } catch {}
        }
      }
    }
  }
}

module.exports = { Reflex };
