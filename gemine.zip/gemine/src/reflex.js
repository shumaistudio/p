// 反射行動: Geminiを介さず即座に動く。終わった後に推論を要求する。
const { goals } = require('mineflayer-pathfinder');
const { sleep } = require('./util');
const { canSee } = require('./vision');

const HOSTILE = new Set([
  'zombie', 'zombie_villager', 'husk', 'drowned', 'skeleton', 'stray', 'bogged',
  'spider', 'cave_spider', 'creeper', 'witch', 'pillager', 'vindicator', 'slime',
  'phantom', 'silverfish', 'blaze', 'wither_skeleton',
]);
const RANGED = new Set(['skeleton', 'stray', 'bogged', 'witch', 'pillager', 'blaze']);
const TIER = ['netherite', 'diamond', 'iron', 'stone', 'golden', 'wooden'];
const BAD_FOOD = new Set(['rotten_flesh', 'spider_eye', 'pufferfish', 'poisonous_potato', 'chorus_fruit']);
const ARMOR = { _helmet: [5, 'head'], _chestplate: [6, 'torso'], _leggings: [7, 'legs'], _boots: [8, 'feet'] };

class Reflex {
  constructor(agent) {
    this.agent = agent;
    this.bot = agent.bot;
    this.active = false;   // 反射行動の実行中
    this.fighting = false; // 戦闘中(行動としての攻撃も含む)
    this.lastEat = 0;
    this.lastArmor = 0;
    this.noticeId = null;  // 脅威に「気づく」までの反応遅延用
    this.noticeAt = 0;
    this.ignore = new Map(); // 倒せず時間切れになった相手はしばらく無視する
    this.timer = setInterval(() => this.check().catch(() => {}), 250);
  }

  stop() { clearInterval(this.timer); }

  // 距離だけで選ぶ(攻撃行動の対象選びなどに使う)
  hostiles(maxDist) {
    const p = this.bot.entity.position;
    return Object.values(this.bot.entities)
      .filter((e) => e.name && HOSTILE.has(e.name) && e.position.distanceTo(p) <= maxDist)
      .sort((a, b) => a.position.distanceTo(p) - b.position.distanceTo(p));
  }

  // 本当に脅威になる敵だけ。近接系は「殴れる距離」まで来て初めて反応し、遠くから見えているだけでは反応しない
  threats() {
    const p = this.bot.entity.position;
    const now = Date.now();
    return Object.values(this.bot.entities)
      .filter((e) => e.name && HOSTILE.has(e.name) && e.position && !((this.ignore.get(e.id) || 0) > now))
      .map((e) => ({ e, d: e.position.distanceTo(p), dy: Math.abs(e.position.y - p.y) }))
      .filter(({ e, d, dy }) => {
        if (d <= 2.5) return true;               // すぐそばなら音や気配で気づく
        if (dy > 4) return false;                // 上下に離れている(地中など)
        const range = e.name === 'creeper' ? 5.5 : RANGED.has(e.name) ? 12 : 4.5;
        return d <= range && canSee(this.bot, e); // 視線が通っている時だけ
      })
      .sort((a, b) => a.d - b.d);
  }

  // mode: 'clear' = 行動を捨てて終了後に再推論 / 'resume' = 一旦止めて、終わったら元の行動を再開
  // 'resume' でも、大ダメージを受けた・瀕死になった場合は再推論に切り替える
  async trigger(label, fn, mode = 'clear') {
    this.active = true;
    const hp0 = this.bot.health;
    if (mode === 'clear') { this.agent.epoch++; this.agent.interrupt(true); }
    else this.agent.interrupt(false, true);
    let result = '';
    try { result = (await fn()) || ''; } catch {}
    finally {
      this.bot.clearControlStates();
      try { this.bot.pathfinder.setGoal(null); } catch {}
      this.active = false;
      this.agent.memory.pushEvent(`【反射】${label}${result ? `(${result})` : ''} 体力${Math.round(this.bot.health)} 満腹${this.bot.food}`);
      const serious = mode === 'clear' || result === 'low_hp' || hp0 - this.bot.health >= 5;
      if (serious) {
        if (mode !== 'clear') { this.agent.epoch++; this.agent.queue = []; }
        this.agent.requestThink();
      }
    }
  }

  async check() {
    const bot = this.bot;
    if (!bot.entity || bot.health <= 0 || this.active || this.fighting) return;
    const feet = bot.blockAt(bot.entity.position);

    // 1. 溶岩
    if (feet && feet.name === 'lava') return this.trigger('溶岩から脱出した', () => this.escapeLava());
    // 2. 溺れ
    if (feet && feet.name === 'water' && bot.oxygenLevel !== undefined && bot.oxygenLevel <= 8)
      return this.trigger('溺れそうで浮上した', () => this.surface());

    // 3. 脅威(気づくまで少し間を置く=人間らしい反応時間)
    const th = this.threats()[0];
    if (th) {
      const { e, d } = th;
      if (this.noticeId !== e.id) {
        this.noticeId = e.id;
        this.noticeAt = Date.now() + (d <= 2.5 ? 0 : 300 + Math.random() * 400);
      }
      if (Date.now() < this.noticeAt) return;
      if (e.name === 'creeper') return this.trigger('クリーパーから逃げた', () => this.flee(e, 8000));
      if (bot.health <= 6) return this.trigger(`${e.name}から逃げた(体力低下)`, () => this.flee(e, 6000));
      return this.trigger(`${e.name}と戦った`, async () => {
        const r = await this.fight(e, { timeout: 15000 });
        if (r === 'timeout') this.ignore.set(e.id, Date.now() + 20000); // 倒せない相手に張り付き続けない
        return r;
      }, 'resume');
    }
    this.noticeId = null;

    // 4. 空腹(かなり空いたら作業中でも / 少し減った程度なら手が空いた時に)
    const hungry = bot.food <= 8 || (bot.food <= 14 && !this.agent.busy);
    if (hungry && Date.now() - this.lastEat > 8000) {
      this.lastEat = Date.now();
      if (this.findFood(bot.food <= 6)) return this.trigger('食事をした', () => this.eat(), 'resume');
    }
    // 5. 防具の自動装備(手が空いた時だけ。作業を邪魔しない)
    if (!this.agent.busy && Date.now() - this.lastArmor > 5000) { this.lastArmor = Date.now(); await this.autoArmor(); }
  }

  async escapeLava() {
    const bot = this.bot;
    await bot.look(Math.random() * Math.PI * 2, 0, true);
    bot.setControlState('jump', true); bot.setControlState('sprint', true); bot.setControlState('forward', true);
    await sleep(2500);
  }

  async surface() {
    const bot = this.bot;
    bot.setControlState('jump', true);
    const t0 = Date.now();
    while (Date.now() - t0 < 6000 && (bot.oxygenLevel ?? 20) < 18) await sleep(200);
  }

  async flee(threat, ms) {
    const bot = this.bot;
    bot.pathfinder.setGoal(new goals.GoalInvert(new goals.GoalFollow(threat, 12)), true);
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      await sleep(300);
      if (!threat.isValid) break;
      const d = threat.position.distanceTo(bot.entity.position);
      if (d > 12 || (d > 6 && !this.canSee(threat))) break;
    }
    bot.pathfinder.setGoal(null);
  }

  weaponRank(item) {
    const idx = TIER.findIndex((t) => item.name.startsWith(t + '_'));
    if (idx < 0) return -1;
    return (item.name.endsWith('_sword') ? 20 : item.name.endsWith('_axe') ? 10 : 0) + (10 - idx);
  }

  async fight(target, { timeout = 20000, stop = () => false } = {}) {
    const bot = this.bot;
    this.fighting = true;
    try {
      const w = bot.inventory.items().filter((i) => this.weaponRank(i) >= 0).sort((a, b) => this.weaponRank(b) - this.weaponRank(a))[0];
      if (w) await bot.equip(w, 'hand').catch(() => {});
      const t0 = Date.now();
      while (target.isValid && Date.now() - t0 < timeout && !stop()) {
        if (bot.health <= 6) return 'low_hp';
        const d = bot.entity.position.distanceTo(target.position);
        if (d > 3) {
          bot.pathfinder.setGoal(new goals.GoalFollow(target, 2), true);
          await sleep(200);
        } else {
          bot.pathfinder.setGoal(null);
          await bot.lookAt(target.position.offset(0, target.height * 0.8, 0));
          bot.attack(target);
          await sleep(600);
        }
      }
      return target.isValid ? 'timeout' : 'killed';
    } finally {
      bot.pathfinder.setGoal(null);
      this.fighting = false;
    }
  }

  findFood(allowBad = false) {
    const reg = this.bot.registry.foodsByName;
    return this.bot.inventory.items()
      .filter((i) => reg[i.name] && (allowBad || !BAD_FOOD.has(i.name)))
      .sort((a, b) => reg[b.name].foodPoints - reg[a.name].foodPoints)[0];
  }

  async eat() {
    const food = this.findFood(this.bot.food <= 6);
    if (!food) throw new Error('食べ物がない');
    await this.bot.equip(food, 'hand');
    await this.bot.consume();
  }

  async autoArmor() {
    const bot = this.bot;
    for (const item of bot.inventory.items()) {
      for (const [suffix, [slot, dest]] of Object.entries(ARMOR)) {
        if (item.name.endsWith(suffix) && !bot.inventory.slots[slot]) {
          try { await bot.equip(item, dest); this.agent.memory.pushEvent(`${item.name}を装備した`); } catch {}
        }
      }
    }
  }
}

module.exports = { Reflex };
