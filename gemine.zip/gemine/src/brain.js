const { GoogleGenAI } = require('@google/genai');
const { sleep, log } = require('./util');

function parseJson(text) {
  let t = String(text || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  let obj;
  try { obj = JSON.parse(t); }
  catch {
    const s = t.indexOf('{'), e = t.lastIndexOf('}');
    if (s < 0 || e < 0) throw new Error('JSONを解釈できない');
    obj = JSON.parse(t.slice(s, e + 1));
  }
  return Array.isArray(obj) ? obj[0] : obj;
}

class Brain {
  constructor(apiKey, models, name) {
    if (!apiKey) throw new Error(`${name}のGemini APIキーが未設定です(.env)`);
    this.ai = new GoogleGenAI({ apiKey });
    this.models = models;
    this.name = name;
    this.exhaustedDay = null;
  }

  // 日次クォータはアメリカ太平洋時間の0時にリセットされる
  dayKey() {
    return new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' });
  }

  currentModel() {
    return this.exhaustedDay === this.dayKey() ? this.models.fallback : this.models.primary;
  }

  async decide(system, user, imageBase64 = null) {
    for (let attempt = 0; attempt < 4; attempt++) {
      const model = this.currentModel();
      try {
        const res = await this.ai.models.generateContent({
          model,
          contents: imageBase64
            ? [{ role: 'user', parts: [{ text: user }, { inlineData: { mimeType: 'image/png', data: imageBase64 } }] }]
            : user,
          config: {
            systemInstruction: system,
            responseMimeType: 'application/json',
            temperature: 1.0,
            maxOutputTokens: 2048,
          },
        });
        return parseJson(res.text);
      } catch (e) {
        const msg = String(e.message || e);
        const status = e.status || e.code;
        const quota = status === 429 || /RESOURCE_EXHAUSTED|quota/i.test(msg);
        if (quota) {
          if (/PerDay|per day|daily/i.test(msg)) {
            if (model === this.models.primary) {
              this.exhaustedDay = this.dayKey();
              log(this.name, `日次上限 → ${this.models.fallback} に切り替え`);
              continue;
            }
            throw new Error('両モデルとも日次上限に達した');
          }
          const m = msg.match(/retry(?:Delay)?\D{0,10}([\d.]+)\s*s/i);
          const wait = m ? Number(m[1]) * 1000 + 500 : 20000;
          log(this.name, `レート制限。${Math.round(wait / 1000)}秒待機`);
          await sleep(wait);
          continue;
        }
        if ((status >= 500 && status < 600) || /fetch|ECONN|timeout|JSON/i.test(msg)) {
          await sleep(3000);
          continue;
        }
        throw e;
      }
    }
    throw new Error('Geminiの応答取得に失敗');
  }
}

module.exports = { Brain };
