const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (name, ...a) => console.log(`[${new Date().toLocaleTimeString()}] [${name}]`, ...a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
module.exports = { sleep, log, clamp };
