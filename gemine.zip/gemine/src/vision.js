// 視覚まわり: 視線判定(壁越しは見えない)と、bot視点の簡易3D描画(Geminiが要求した時だけ使う)
const { Vec3 } = require('vec3');
const { PNG } = require('pngjs');

const EMPTY = 0, SOLID = 1, WATER = 2, LAVA = 3, VOID = 4;

const COLOR_WORDS = {
  white: [235, 235, 235], orange: [230, 140, 40], magenta: [190, 80, 200], light_blue: [100, 170, 230],
  yellow: [240, 220, 60], lime: [130, 200, 40], pink: [240, 150, 180], gray: [75, 75, 75],
  light_gray: [150, 150, 150], cyan: [40, 150, 160], purple: [130, 50, 170], blue: [50, 70, 170],
  brown: [110, 70, 40], green: [80, 110, 40], red: [170, 45, 45], black: [25, 25, 30],
};
const WORDS_SORTED = Object.keys(COLOR_WORDS).sort((a, b) => b.length - a.length);
const RULES = [
  [/^lava$/, [255, 110, 20]],
  [/diamond_ore/, [70, 215, 215]], [/emerald_ore/, [30, 190, 80]], [/gold_ore/, [235, 200, 50]],
  [/iron_ore/, [205, 155, 125]], [/coal_ore/, [40, 40, 40]], [/redstone_ore/, [200, 30, 30]],
  [/lapis_ore/, [40, 70, 190]], [/copper_ore/, [200, 120, 80]],
  [/deepslate/, [70, 70, 78]],
  [/bedrock/, [35, 35, 35]], [/obsidian/, [20, 10, 35]], [/netherrack/, [110, 40, 40]],
  [/grass_block|^moss_block|podzol|mycelium/, [95, 160, 55]],
  [/dirt|farmland|mud|rooted/, [134, 96, 67]],
  [/sandstone|sand$/, [219, 207, 163]], [/gravel/, [136, 126, 126]], [/snow/, [245, 250, 250]],
  [/ice$/, [160, 200, 255]], [/clay/, [160, 166, 179]],
  [/leaves/, [55, 115, 40]],
  [/(log|wood|stem|hyphae)$/, [105, 82, 52]],
  [/planks|_slab$|_stairs$|_fence|_door$|trapdoor|crafting_table|bookshelf|chest|barrel|_sign|ladder|^bed|_bed$/, [172, 136, 86]],
  [/stone|andesite|diorite|granite|tuff|calcite|blackstone|basalt|bricks|furnace|dispenser|dropper/, [128, 128, 128]],
  [/glass|iron_bars/, [200, 230, 240]],
];
function hashColor(name) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return [90 + (h & 127), 90 + ((h >> 7) & 127), 90 + ((h >> 14) & 127)];
}
function colorOf(name) {
  for (const [re, c] of RULES) if (re.test(name)) return c;
  if (/(wool|concrete|terracotta|carpet|stained_glass|shulker_box|banner|candle)/.test(name))
    for (const w of WORDS_SORTED) if (name.includes(w)) return COLOR_WORDS[w];
  return hashColor(name);
}

const clsCache = new Map();
function classify(def) {
  if (!def) return { kind: VOID };
  let c = clsCache.get(def.name);
  if (c) return c;
  const n = def.name;
  if (n === 'air' || n === 'cave_air' || n === 'void_air') c = { kind: EMPTY };
  else if (n === 'water' || n === 'bubble_column') c = { kind: WATER };
  else if (n === 'lava') c = { kind: LAVA, color: colorOf(n) };
  else if (def.boundingBox === 'empty') c = { kind: EMPTY };
  else c = { kind: SOLID, color: colorOf(n), transparent: /glass|iron_bars/.test(n) };
  clsCache.set(n, c);
  return c;
}

const readers = new WeakMap();
function reader(bot) {
  let r = readers.get(bot);
  if (r) return r;
  const byState = bot.registry.blocksByStateId;
  const tmp = new Vec3(0, 0, 0);
  const fast = typeof bot.world.getBlockStateId === 'function';
  r = (x, y, z) => {
    tmp.x = x; tmp.y = y; tmp.z = z;
    try {
      if (fast) { const id = bot.world.getBlockStateId(tmp); return id == null ? null : byState[id] || null; }
      const b = bot.blockAt(tmp); return b ? byState[b.stateId] || null : null;
    } catch { return null; }
  };
  readers.set(bot, r);
  return r;
}

function lineClear(get, ax, ay, az, bx, by, bz) {
  const dx = bx - ax, dy = by - ay, dz = bz - az;
  const n = Math.max(1, Math.ceil(Math.hypot(dx, dy, dz) / 0.35));
  for (let i = 1; i < n; i++) {
    const f = i / n;
    const c = classify(get(Math.floor(ax + dx * f), Math.floor(ay + dy * f), Math.floor(az + dz * f)));
    if (c.kind === SOLID && !c.transparent) return false;
  }
  return true;
}

// そのエンティティが目で見える(視線が壁・地面に遮られていない)か
function canSee(bot, e) {
  const get = reader(bot);
  const eye = bot.entity.position.offset(0, 1.5, 0);
  const h = e.height || 1.8;
  for (const f of [0.85, 0.4]) {
    if (lineClear(get, eye.x, eye.y, eye.z, e.position.x, e.position.y + h * f, e.position.z)) return true;
  }
  return false;
}

// ブロックの面のどれかが空気や水に面している(地中に埋まっていない)か
function isExposed(bot, pos) {
  const get = reader(bot);
  for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
    const c = classify(get(pos.x + dx, pos.y + dy, pos.z + dz));
    if (c.kind === EMPTY || c.kind === WATER) return true;
  }
  return false;
}

const hash3 = (x, y, z) => {
  let h = (x * 374761393 + y * 668265263 + z * 2147483647) | 0;
  h = (h ^ (h >>> 13)) * 1274126177;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
};
const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const frac = (v) => v - Math.floor(v);

function compass(fx, fz) {
  if (Math.abs(fx) > Math.abs(fz)) return fx < 0 ? '西' : '東';
  return fz < 0 ? '北' : '南';
}

// bot視点の簡易描画。テクスチャは無く、ブロックごとの色と格子線で表現する
async function renderView(bot, { yaw, pitch, width = 320, height = 180, maxDist = 40 } = {}) {
  const get = reader(bot);
  const eye = bot.entity.position.offset(0, 1.62, 0);
  const cp = Math.cos(pitch), sp = Math.sin(pitch);
  const fwd = [-Math.sin(yaw) * cp, sp, -Math.cos(yaw) * cp];
  const right = [Math.cos(yaw), 0, -Math.sin(yaw)];
  const up = [
    right[1] * fwd[2] - right[2] * fwd[1],
    right[2] * fwd[0] - right[0] * fwd[2],
    right[0] * fwd[1] - right[1] * fwd[0],
  ];
  const tanH = 1.15, tanV = tanH * height / width;
  const t = bot.time ? bot.time.timeOfDay : 0;
  const night = t >= 13000 && t < 23000;
  const SKY = night ? [12, 14, 34] : [135, 190, 235];
  const WATER_C = [30, 80, 170];
  const dim = night ? 0.6 : 1;

  const data = Buffer.alloc(width * height * 4);
  const depth = new Float32Array(width * height).fill(maxDist);
  const eyeCell = classify(get(Math.floor(eye.x), Math.floor(eye.y), Math.floor(eye.z)));

  for (let r = 0; r < height; r++) {
    for (let c = 0; c < width; c++) {
      const sx = ((c + 0.5) / width) * 2 - 1, sy = 1 - ((r + 0.5) / height) * 2;
      let dx = fwd[0] + right[0] * sx * tanH + up[0] * sy * tanV;
      let dy = fwd[1] + right[1] * sx * tanH + up[1] * sy * tanV;
      let dz = fwd[2] + right[2] * sx * tanH + up[2] * sy * tanV;
      const len = Math.hypot(dx, dy, dz); dx /= len; dy /= len; dz /= len;

      let x = Math.floor(eye.x), y = Math.floor(eye.y), z = Math.floor(eye.z);
      const sX = dx > 0 ? 1 : -1, sY = dy > 0 ? 1 : -1, sZ = dz > 0 ? 1 : -1;
      const dX = dx !== 0 ? Math.abs(1 / dx) : Infinity, dY = dy !== 0 ? Math.abs(1 / dy) : Infinity, dZ = dz !== 0 ? Math.abs(1 / dz) : Infinity;
      let mX = dx > 0 ? (x + 1 - eye.x) / dx : dx < 0 ? (eye.x - x) / -dx : Infinity;
      let mY = dy > 0 ? (y + 1 - eye.y) / dy : dy < 0 ? (eye.y - y) / -dy : Infinity;
      let mZ = dz > 0 ? (z + 1 - eye.z) / dz : dz < 0 ? (eye.z - z) / -dz : Infinity;
      let tt = 0, face = 1, wetT = eyeCell.kind === WATER ? 0 : -1;
      let col = null, hitT = maxDist;

      for (;;) {
        if (mX < mY && mX < mZ) { x += sX; tt = mX; mX += dX; face = 0; }
        else if (mY < mZ) { y += sY; tt = mY; mY += dY; face = 1; }
        else { z += sZ; tt = mZ; mZ += dZ; face = 2; }
        if (tt > maxDist) break;
        const info = classify(get(x, y, z));
        if (info.kind === EMPTY) continue;
        if (info.kind === WATER) { if (wetT < 0) wetT = tt; continue; }
        if (info.kind === VOID) break;
        // 固体・溶岩に命中
        let shade = info.kind === LAVA ? 1 : face === 1 ? (dy < 0 ? 1 : 0.5) : face === 0 ? 0.8 : 0.65;
        shade *= 0.92 + hash3(x, y, z) * 0.16;
        const hx = eye.x + dx * tt, hy = eye.y + dy * tt, hz = eye.z + dz * tt;
        const u = face === 0 ? frac(hy) : frac(hx), v = face === 2 ? frac(hy) : frac(hz);
        if (u < 0.04 || u > 0.96 || v < 0.04 || v > 0.96) shade *= 0.78; // ブロックの境目
        col = info.color.map((k) => k * shade * (info.kind === LAVA ? 1 : dim));
        hitT = tt;
        break;
      }
      if (!col) col = sy > 0 || wetT < 0 ? SKY : WATER_C;
      else {
        if (wetT >= 0) col = mix(col, WATER_C, Math.min(0.9, 0.3 + (hitT - wetT) * 0.07));
        col = mix(col, SKY, Math.min(1, Math.pow(hitT / maxDist, 1.5) * 0.8)); // 遠くは霞む
      }
      const i = (r * width + c) * 4;
      data[i] = col[0]; data[i + 1] = col[1]; data[i + 2] = col[2]; data[i + 3] = 255;
      depth[r * width + c] = hitT;
    }
    if (r % 12 === 11) await new Promise((res) => setImmediate(res)); // 反射処理を止めない
  }

  // エンティティ(敵=赤, プレイヤー=青, ドロップ=黄, その他の生き物=緑)
  const seen = [];
  const proj = (px, py, pz) => {
    const vx = px - eye.x, vy = py - eye.y, vz = pz - eye.z;
    const z = vx * fwd[0] + vy * fwd[1] + vz * fwd[2];
    if (z < 0.1) return null;
    const x = vx * right[0] + vz * right[2];
    const y = vx * up[0] + vy * up[1] + vz * up[2];
    return [((x / z / tanH + 1) / 2) * width, ((1 - y / z / tanV) / 2) * height];
  };
  const HOSTILE = /zombie|skeleton|creeper|spider|witch|husk|drowned|stray|bogged|pillager|vindicator|slime|phantom|silverfish|blaze/;
  for (const e of Object.values(bot.entities)) {
    if (e === bot.entity || !e.position) continue;
    const d = e.position.distanceTo(eye);
    if (d > maxDist) continue;
    const w = (e.width || 0.6) / 2, h = e.height || 1.8;
    const pts = [];
    for (const ox of [-w, w]) for (const oz of [-w, w]) for (const oy of [0, h]) pts.push(proj(e.position.x + ox, e.position.y + oy, e.position.z + oz));
    if (pts.some((p) => !p)) continue;
    const x0 = Math.max(0, Math.floor(Math.min(...pts.map((p) => p[0])))), x1 = Math.min(width - 1, Math.ceil(Math.max(...pts.map((p) => p[0]))));
    const y0 = Math.max(0, Math.floor(Math.min(...pts.map((p) => p[1])))), y1 = Math.min(height - 1, Math.ceil(Math.max(...pts.map((p) => p[1]))));
    const name = e.username || e.name || 'entity';
    const base = e.type === 'player' ? [60, 120, 255] : e.name === 'item' ? [255, 220, 0] : (e.type === 'hostile' || HOSTILE.test(e.name || '')) ? [255, 50, 50] : [80, 220, 80];
    const k = 1 - Math.min(0.5, d / maxDist * 0.5);
    let drawn = 0;
    for (let yy = y0; yy <= y1; yy++) for (let xx = x0; xx <= x1; xx++) {
      if (d > depth[yy * width + xx]) continue; // 手前の地形に隠れている
      const i = (yy * width + xx) * 4;
      data[i] = base[0] * k; data[i + 1] = base[1] * k; data[i + 2] = base[2] * k;
      drawn++;
    }
    if (drawn > 0) {
      const cx = (x0 + x1) / 2;
      seen.push(`${name}(${Math.round(d)}m, ${cx < width * 0.35 ? '左' : cx > width * 0.65 ? '右' : '正面'})`);
    }
  }
  // 中央の十字
  for (let k = -3; k <= 3; k++) for (const [xx, yy] of [[width / 2 + k, height / 2], [width / 2, height / 2 + k]]) {
    const i = (Math.floor(yy) * width + Math.floor(xx)) * 4; data[i] = data[i + 1] = data[i + 2] = 255;
  }

  const png = new PNG({ width, height });
  png.data = data;
  return {
    png: PNG.sync.write(png),
    note: `向き: ${compass(fwd[0], fwd[2])}${pitch < -0.5 ? '(下を向いている)' : pitch > 0.5 ? '(上を向いている)' : ''} / 画像内に見える生き物: ${seen.join('、') || 'なし'}`,
  };
}

module.exports = { canSee, isExposed, renderView };
