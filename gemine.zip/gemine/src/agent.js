const mineflayer = require('mineflayer');
const { pathfinder, Movements } = require('mineflayer-pathfinder');
const { plugin: toolPlugin } = require('mineflayer-tool');
const { Brain } = require('./brain');
const { Memory } = require('./memory');
const { Actions } = require('./actions');
const { Reflex } = require('./reflex');
const { observe } = require('./observe');
const { systemPrompt, userPrompt } = require('./prompt');
const { renderView } = require('./vision');
const fs = require('fs');
const path = require('path');
const { log, clamp } = require('./util');

class Agent {
  constructor(cfg, config) {
    this.cfg = cfg;
    this.config = config;
    this.name = cfg.name;
    this.partners = config.bots.map((b) => b.name).filter((n) => n !== cfg.name);
    this.memory = new Memory(cfg, this.partners);
    this.brain = new Brain(cfg.apiKey, config.models, cfg.name);
    this.system = systemPrompt(cfg, this.partners);

    this.queue = [];          // 行動キュー
    this.current = null;      // 実行中の行動
    this.busy = false;
    this.thinking = false;
    this.thinkRequested = true;
    this.thinkNotBefore = 0;
    this.lastThink = 0;
    this.lastLook = 0;
    this.epoch = 0;           // 反射が起きたら増える。古い計画を捨てるため
    this.stopped = false;
  }

  connect() {
    const { server } = this.config;
    const bot = mineflayer.createBot({
      host: server.host, port: server.port, version: server.version,
      username: this.name, auth: 'offline',
    });
    this.bot = bot;
    bot.loadPlugin(pathfinder);
    bot.loadPlugin(toolPlugin);

    bot.once('spawn', () => this.onSpawn());
    bot.on('respawn', () => { this.memory.pushEvent('リスポーンした'); this.requestThink(); });
    bot.on('death', () => {
      this.interrupt(true);
      this.memory.pushEvent('死んでしまった…');
      this.memory.add('一度死んだ。持ち物を失った。同じ失敗はしたくない。', 8);
      log(this.name, '☠ 死亡');
    });
    bot.on('chat', (username, message) => {
      if (username === bot.username) return;
      this.memory.pushEvent(`${username}「${message}」`);
      log(this.name, `💬 ${username}: ${message}`);
      this.requestThink(2500); // 続けて話しかけられてもまとめて1回の推論にする
    });
    bot.on('playerCollect', (collector, item) => {
      if (collector === bot.entity) this.memory.pushEvent('アイテムを拾った');
    });
    bot.on('kicked', (r) => log(this.name, 'kicked:', JSON.stringify(r)));
    bot.on('error', (e) => log(this.name, 'error:', e.message));
    bot.on('end', (reason) => {
      log(this.name, `切断(${reason})。10秒後に再接続`);
      this.teardown();
      if (!this.stopped) setTimeout(() => this.connect(), 10000);
    });
  }

  onSpawn() {
    const bot = this.bot;
    const mv = new Movements(bot);
    mv.canDig = true;
    mv.allowSprinting = true;
    const scaffold = ['dirt', 'cobblestone'].map((n) => bot.registry.itemsByName[n]).filter(Boolean).map((i) => i.id);
    mv.scafoldingBlocks = scaffold;
    bot.pathfinder.setMovements(mv);

    this.actions = new Actions(this);
    this.reflex = new Reflex(this);
    this.memory.pushEvent('この世界で目を覚ました');
    this.ticker = setInterval(() => this.tick().catch((e) => log(this.name, 'tick error', e.message)), 500);
    log(this.name, '✅ スポーン。自律行動を開始');
  }

  teardown() {
    clearInterval(this.ticker);
    if (this.reflex) this.reflex.stop();
    this.queue = []; this.current = null; this.busy = false; this.thinking = false;
  }

  requestThink(delayMs = 0) {
    this.thinkRequested = true;
    this.thinkNotBefore = Math.max(this.thinkNotBefore, Date.now() + delayMs);
  }

  // requeue=true: 実行中の行動を先頭に戻す(反射が終わったら再開できる)
  interrupt(clearQueue, requeue = false) {
    if (requeue && this.current) {
      const { type, args, priority } = this.current;
      this.queue.unshift({ type, args, priority });
    }
    if (this.current) this.current.ctx.cancelled = true;
    try { this.bot.pathfinder.stop(); } catch {}
    try { this.bot.clearControlStates(); } catch {}
    if (clearQueue) this.queue = [];
  }

  shouldThink() {
    if (this.thinking) return false;
    const now = Date.now();
    const since = now - this.lastThink;
    const c = this.config;
    if (this.thinkRequested) return since >= c.chatThinkIntervalMs && now >= this.thinkNotBefore; // 会話・反射後
    if (!this.busy && this.queue.length === 0) return since >= c.minThinkIntervalMs;              // 行動が尽きた
    return since >= c.idleThinkIntervalMs;                                                        // 長い行動の途中
  }

  async tick() {
    if (!this.bot.entity) return;
    if (this.shouldThink()) this.think(); // 並行して推論(行動は止めない)
    if (this.busy || this.reflex.active) return;
    const act = this.queue.shift();
    if (!act) return;

    this.busy = true;
    this.current = { ...act, ctx: { cancelled: false } };
    log(this.name, `▶ ${act.type} ${JSON.stringify(act.args)} [優先度${act.priority}]`);
    const result = await this.actions.run(act, this.current.ctx);
    log(this.name, `   → ${result}`);
    if (result !== '中断された') this.memory.pushEvent(`行動 ${act.type}: ${result}`);
    this.current = null;
    this.busy = false;
  }

  lookWaitSec() {
    return Math.max(0, Math.ceil((this.lastLook + this.config.viewCooldownMs - Date.now()) / 1000));
  }

  // Geminiが要求した時だけ、bot視点の画像を作る
  async captureView(dir) {
    const bot = this.bot;
    const offsets = { front: [0, 0], left: [Math.PI / 2, 0], right: [-Math.PI / 2, 0], back: [Math.PI, 0], down: [0, -1.2], up: [0, 1.0] };
    const [dy, pitch] = offsets[dir] || offsets.front;
    const out = await renderView(bot, { yaw: bot.entity.yaw + dy, pitch: pitch === 0 ? bot.entity.pitch : pitch });
    this.lastLook = Date.now();
    try { // 観察用: Geminiが見た最新の画像を保存
      fs.writeFileSync(path.join(__dirname, '..', 'data', `${this.name}_view.png`), out.png);
    } catch {}
    this.memory.pushEvent(`周囲を見た(${dir})`);
    return { base64: out.png.toString('base64'), note: out.note };
  }

  async think() {
    this.thinking = true;
    this.thinkRequested = false;
    const epoch = this.epoch;
    try {
      const state = observe(this);
      let plan = await this.brain.decide(this.system, userPrompt(this, state, { lookWaitSec: this.lookWaitSec() }));
      // 視界の要求があれば、画像を付けてもう一度だけ決めてもらう
      if (plan && plan.look && this.lookWaitSec() === 0) {
        try {
          const view = await this.captureView(String(plan.look));
          log(this.name, `👁 視界を確認 (${plan.look}) ${view.note}`);
          plan = await this.brain.decide(this.system, userPrompt(this, observe(this), { viewNote: view.note }), view.base64);
        } catch (e) { log(this.name, '視界取得エラー:', e.message); }
      }
      if (epoch !== this.epoch) return; // 推論中に反射が起きた → 古い計画は捨てる
      this.applyPlan(plan);
    } catch (e) {
      log(this.name, '推論エラー:', e.message);
    } finally {
      this.lastThink = Date.now();
      this.thinking = false;
    }
  }

  applyPlan(plan) {
    if (!plan || typeof plan !== 'object') return;
    const m = this.memory;
    if (plan.thought) log(this.name, `💭 ${plan.thought}`);
    if (plan.mood) m.data.mood = String(plan.mood).slice(0, 30);
    if (plan.goal) m.data.goal = String(plan.goal).slice(0, 100);
    if (Array.isArray(plan.memory)) for (const x of plan.memory) if (x && x.text) m.add(x.text, x.importance);
    if (plan.affinity && typeof plan.affinity === 'object')
      for (const [k, v] of Object.entries(plan.affinity)) m.adjustAffinity(k, Number(v));
    m.save();

    const acts = (Array.isArray(plan.actions) ? plan.actions : [])
      .filter((a) => a && this.actions.handlers[a.type])
      .slice(0, 12)
      .map((a) => ({ type: a.type, args: a.args || {}, priority: clamp(Number(a.priority) || 5, 1, 10) }));
    if (!acts.length) return;

    // 実行中の行動より優先度が高ければ割り込む。そうでなければ現在の行動の完了後に新計画へ
    if (this.current && acts[0].priority >= this.current.priority + 3) this.interrupt(false); // 明らかに緊急な時だけ割り込む
    this.queue = acts;
    log(this.name, `📋 計画: ${acts.map((a) => `${a.type}(${a.priority})`).join(' → ')}`);
  }
}

module.exports = { Agent };
