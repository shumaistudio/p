const mineflayer = require('mineflayer');
const { pathfinder, Movements } = require('mineflayer-pathfinder');
const { plugin: toolPlugin } = require('mineflayer-tool');
const { Brain } = require('./brain');
const { Memory } = require('./memory');
const { Actions } = require('./actions');
const { Reflex } = require('./reflex');
const { observe } = require('./observe');
const { systemPrompt, userPrompt } = require('./prompt');
const { log, clamp } = require('./util');

class Agent {
  constructor(cfg, config) {
    this.cfg = cfg;
    this.config = config;
    this.name = cfg.name;
    this.partners = config.bots.map((b) => b.name).filter((n) => n !== cfg.name);
    this.memory = new Memory(cfg, this.partners);
    this.brain = new Brain(cfg.apiKey, config.models, cfg.name);
    this.system = systemPrompt(cfg, this.partners);

    this.queue = [];          // 行動キュー
    this.current = null;      // 実行中の行動
    this.busy = false;
    this.thinking = false;
    this.thinkRequested = true;
    this.lastThink = 0;
    this.epoch = 0;           // 反射が起きたら増える。古い計画を捨てるため
    this.stopped = false;
  }

  connect() {
    const { server } = this.config;
    const bot = mineflayer.createBot({
      host: server.host, port: server.port, version: server.version,
      username: this.name, auth: 'offline',
    });
    this.bot = bot;
    bot.loadPlugin(pathfinder);
    bot.loadPlugin(toolPlugin);

    bot.once('spawn', () => this.onSpawn());
    bot.on('respawn', () => { this.memory.pushEvent('リスポーンした'); this.thinkRequested = true; });
    bot.on('death', () => {
      this.interrupt(true);
      this.memory.pushEvent('死んでしまった…');
      this.memory.add('一度死んだ。持ち物を失った。同じ失敗はしたくない。', 8);
      log(this.name, '☠ 死亡');
    });
    bot.on('chat', (username, message) => {
      if (username === bot.username) return;
      this.memory.pushEvent(`${username}「${message}」`);
      log(this.name, `💬 ${username}: ${message}`);
      this.thinkRequested = true;
    });
    bot.on('playerCollect', (collector, item) => {
      if (collector === bot.entity) this.memory.pushEvent('アイテムを拾った');
    });
    bot.on('kicked', (r) => log(this.name, 'kicked:', JSON.stringify(r)));
    bot.on('error', (e) => log(this.name, 'error:', e.message));
    bot.on('end', (reason) => {
      log(this.name, `切断(${reason})。10秒後に再接続`);
      this.teardown();
      if (!this.stopped) setTimeout(() => this.connect(), 10000);
    });
  }

  onSpawn() {
    const bot = this.bot;
    const mv = new Movements(bot);
    mv.canDig = true;
    mv.allowSprinting = true;
    const scaffold = ['dirt', 'cobblestone'].map((n) => bot.registry.itemsByName[n]).filter(Boolean).map((i) => i.id);
    mv.scafoldingBlocks = scaffold;
    bot.pathfinder.setMovements(mv);

    this.actions = new Actions(this);
    this.reflex = new Reflex(this);
    this.memory.pushEvent('この世界で目を覚ました');
    this.ticker = setInterval(() => this.tick().catch((e) => log(this.name, 'tick error', e.message)), 500);
    log(this.name, '✅ スポーン。自律行動を開始');
  }

  teardown() {
    clearInterval(this.ticker);
    if (this.reflex) this.reflex.stop();
    this.queue = []; this.current = null; this.busy = false; this.thinking = false;
  }

  interrupt(clearQueue) {
    if (this.current) this.current.ctx.cancelled = true;
    try { this.bot.pathfinder.stop(); } catch {}
    try { this.bot.clearControlStates(); } catch {}
    if (clearQueue) this.queue = [];
  }

  shouldThink() {
    if (this.thinking) return false;
    const since = Date.now() - this.lastThink;
    if (since < this.config.minThinkIntervalMs) return false;
    if (this.thinkRequested) return true;
    if (!this.busy && this.queue.length === 0) return true;
    return since > this.config.idleThinkIntervalMs;
  }

  async tick() {
    if (!this.bot.entity) return;
    if (this.shouldThink()) this.think(); // 並行して推論(行動は止めない)
    if (this.busy || this.reflex.active) return;
    const act = this.queue.shift();
    if (!act) return;

    this.busy = true;
    this.current = { ...act, ctx: { cancelled: false } };
    log(this.name, `▶ ${act.type} ${JSON.stringify(act.args)} [優先度${act.priority}]`);
    const result = await this.actions.run(act, this.current.ctx);
    log(this.name, `   → ${result}`);
    this.memory.pushEvent(`行動 ${act.type}: ${result}`);
    this.current = null;
    this.busy = false;
  }

  async think() {
    this.thinking = true;
    this.thinkRequested = false;
    const epoch = this.epoch;
    try {
      const state = observe(this);
      const plan = await this.brain.decide(this.system, userPrompt(this, state));
      if (epoch !== this.epoch) return; // 推論中に反射が起きた → 古い計画は捨てる
      this.applyPlan(plan);
    } catch (e) {
      log(this.name, '推論エラー:', e.message);
    } finally {
      this.lastThink = Date.now();
      this.thinking = false;
    }
  }

  applyPlan(plan) {
    if (!plan || typeof plan !== 'object') return;
    const m = this.memory;
    if (plan.thought) log(this.name, `💭 ${plan.thought}`);
    if (plan.mood) m.data.mood = String(plan.mood).slice(0, 30);
    if (plan.goal) m.data.goal = String(plan.goal).slice(0, 100);
    if (Array.isArray(plan.memory)) for (const x of plan.memory) if (x && x.text) m.add(x.text, x.importance);
    if (plan.affinity && typeof plan.affinity === 'object')
      for (const [k, v] of Object.entries(plan.affinity)) m.adjustAffinity(k, Number(v));
    m.save();

    const acts = (Array.isArray(plan.actions) ? plan.actions : [])
      .filter((a) => a && this.actions.handlers[a.type])
      .slice(0, 12)
      .map((a) => ({ type: a.type, args: a.args || {}, priority: clamp(Number(a.priority) || 5, 1, 10) }));
    if (!acts.length) return;

    // 実行中の行動より優先度が高ければ割り込む。そうでなければ現在の行動の完了後に新計画へ
    if (this.current && acts[0].priority > this.current.priority) this.interrupt(false);
    this.queue = acts;
    log(this.name, `📋 計画: ${acts.map((a) => `${a.type}(${a.priority})`).join(' → ')}`);
  }
}

module.exports = { Agent };
