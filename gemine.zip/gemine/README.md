# gemine

Gemini駆動の自律Minecraft bot 2人(Reimu / Marisa)が、サバイバルでどう生きるかを**観察する**プロジェクト。
プレイヤーは一切干渉せず、見ているだけ。

## セットアップ
1. **サーバー**: Java 1.21.4 のサーバー(Paper等)を用意し、`server.properties` で `online-mode=false` にする。
   (botはオフライン認証で入るため。シングルプレイのLAN公開では入れません)
   観察用には自分のアカウントで入り、`/gamemode spectator` で見ると干渉しません。
2. `npm install`
3. `cp .env.example .env` を編集し、Gemini APIキーを2つ(Reimu用・Marisa用)入れる。
4. `npm start`

## 仕様との対応
| 仕様 | 実装 |
|---|---|
| 2人の別人格・記憶・目標 | `src/config.js`(性格・口調・生い立ち・初期目標・初期記憶) |
| 好感度・記憶保持 | `src/memory.js`(好感度0-100、重要度つき長期記憶、時間で忘却、`data/*.json`に永続化) |
| 互いに会話し協力 | チャットを相手が受信→推論のトリガーに。`give`で物資の受け渡し |
| 反射行動 | `src/reflex.js`(溶岩・溺れ・クリーパー回避・近接の敵との戦闘・自動食事・防具装備)。Geminiを介さず即実行し、終了後に推論を要求 |
| 行動の優先度 | 各行動に1-10の優先度。実行中より高い優先度の計画は割り込む。反射は常に最優先 |
| 複数行動を一度に | Geminiが最大12個の行動列をJSONで出力 |
| プレイヤーと同じ行動 | 移動/採掘/クラフト/精錬/設置/装備/食事/睡眠/戦闘/チャット/受け渡し(`src/actions.js`) |
| API負荷の調整 | `.env` の `MIN_THINK_INTERVAL_MS`(20秒)/`CHAT_THINK_INTERVAL_MS`(8秒)/`IDLE_THINK_INTERVAL_MS`(120秒)。増やすほどリクエストが減る |
| 視界画像 | Geminiが `"look"` を要求した時だけ、bot視点を簡易3D描画(`src/vision.js`)して画像として渡す。最新画像は `data/<名前>_view.png` に保存される。`VIEW_COOLDOWN_MS` で要求間隔を制限 |
| 見えないものは分からない | 壁越し・地中の敵や、埋まっている鉱石は状況情報に含まれない |
| API 1bot=1キー | botごとに別の`Brain`(キー)を使用 |
| モデル切替 | 通常 `MODEL_PRIMARY`、日次上限(429 PerDay)検出で `MODEL_FALLBACK`。太平洋時間0時でリセットされ自動で戻る |

## 調整
- 性格や目標を変える → `src/config.js`
- レート制限に当たる → `.env` の `MIN_THINK_INTERVAL_MS` を増やす
- 行動を増やす → `src/actions.js` にハンドラ追加 + `src/prompt.js` の行動一覧に追記
