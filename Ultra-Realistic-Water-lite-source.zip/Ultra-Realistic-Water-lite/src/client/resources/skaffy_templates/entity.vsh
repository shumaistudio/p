#version 330
#extension GL_ARB_separate_shader_objects : require

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <skaffy:hooks_vertex.glsl>
#include <skaffy:template.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
layout(location = 5) in vec3 Normal;

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler1;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler2;
#endif

layout(location = 0) out vec4 skFog;
layout(location = 1) out vec4 skColorBack;
layout(location = 2) out vec4 skColorFront;
layout(location = 3) out vec4 skLightmap;
layout(location = 4) out vec4 skOverlay;
layout(location = 5) out vec4 skUv;
layout(location = 6) out vec3 skPosition;
layout(location = 7) out vec3 skNormal;
layout(location = 15) flat out ivec2 skIds;

void main() {
    ivec2 light = UV2 & ivec2(0xFF);

    SkVertex v;
    v.sk_position = Position;
    v.sk_color = Color;
    v.sk_uv = UV0;
    v.sk_worldPos = Position + sk_cameraPosition;
    v.sk_normal = Normal;
    v.sk_material = 0;
    v.sk_blockLight = float(light.x) / 240.0;
    v.sk_skyLight = float(light.y) / 240.0;
    v.sk_top = false;
    v.sk_isHand = sk_isHand != 0;
    v.sk_entity = (UV1.x >> 4) & 0x7FF;
    v.sk_item = (UV1.y >> 4) & 0x7FF;
    sk_vertexHook(v);

#ifdef SK_SHADOW_PASS
    gl_Position = skShadowClip(v.sk_position);
#else
    gl_Position = ProjMat * ModelViewMat * vec4(v.sk_position, 1.0);
#endif
    skFog = vec4(fog_spherical_distance(v.sk_position), fog_cylindrical_distance(v.sk_position), v.sk_blockLight, v.sk_skyLight);

#ifdef PER_FACE_LIGHTING
    vec2 cardinal = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    skColorBack = minecraft_mix_light_separate(-cardinal, v.sk_color);
    skColorFront = minecraft_mix_light_separate(cardinal, v.sk_color);
#elif defined(NO_CARDINAL_LIGHTING)
    skColorBack = v.sk_color;
    skColorFront = v.sk_color;
#else
    skColorBack = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, v.sk_color);
    skColorFront = skColorBack;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    skLightmap = sample_lightmap(Sampler2, light);
#else
    skLightmap = vec4(1.0);
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
    skOverlay = texelFetch(Sampler1, UV1 & ivec2(15), 0);
#else
    skOverlay = vec4(1.0);
#endif

    vec2 texCoord = v.sk_uv;
#ifdef APPLY_TEXTURE_MATRIX
    texCoord = (TextureMat * vec4(v.sk_uv, 0.0, 1.0)).xy;
#endif
    vec2 glintCoord = vec2(0.0);
#ifdef GLINT
    glintCoord = (TextureMat * vec4(v.sk_uv, 0.0, 1.0)).xy;
#endif
    skUv = vec4(texCoord, glintCoord);
    skPosition = v.sk_position;
    skNormal = Normal;
    skIds = ivec2(v.sk_entity, v.sk_item);
}
