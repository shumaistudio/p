# Ultra Realistic Water lite

**This is a modified version of "Realistic Water" by Skaffy, NOT the original mod.**
Original project (please support it): https://github.com/sskaffy/Realistic-Water
Original author: Skaffy. Distributed under the original license (see LICENSE, kept intact).

## What this lite fork changes
- Fluids (water, lava, slime) are drawn as **simple translucent colour**: no reflections, refraction, ripples, sun glint or foam lace (`/water set simpleShading false` brings the original look back).
- New settings category **"Performance (lite)"** in `/water gui`:
  - `qualityPreset` 0 Potato / 1 Low (default) / 2 Medium / 3 Original - one switch for particle density (resolution), surface mesh detail, solver iterations, whitewater and sleep behaviour.
  - `adaptiveBudget`, `targetFrameMs`, `minBudget` - automatically lowers simulation substeps when frame time goes over the target.
  - `chunkScansPerTick` - CPU-side fluid scan speed.
- Options > Video Settings now has a **Water Settings...** button. The "Water color (lite)" category sets water RGB (0-255), opacity and a cheap metallic shine (used while simpleShading is on).
- Lower default simulation/mesh settings, whitewater off by default.
- Surface mesh detail changes now apply immediately (the bodies are rebuilt).
- The fluid simulation itself still runs on the GPU through Vulkan compute, so the iGPU does the heavy lifting.

---

# Original README (Realistic Water)
A Minecraft mod that adds a lot of cool, realistic stuff from Minecraft Blender animations.

<img width="1280" height="720" alt="New Project - 2026-10-23T184400 247" src="https://github.com/user-attachments/assets/ab90c5d9-7ce1-40f0-b7d1-f16f095327a3" />


#

How to use:

1. Download the latest version from: https://github.com/sskaffy/Realistic-Water/releases/
2. Install Fabric (Tutorial: https://docs.fabricmc.net/players/installing-fabric/)
3. Put the mod to the mods folder
4. Open the game and set the Graphics API in the Video Settings to Vulkan and then restart the game
5. Search up "Realistic" in the creative inventory to look at all the items from the mod
6. Use the "Realistic Convertor" to convert boats, redstone, or any full blocks into realistic blocks that have gravity
7. Remove them: use "/water remove" to remove water and "/water remove <block>" for everything else 
8. Use "Water Pump" to move water in ways it couldn't flow by itself (has to be powered by redstone)
9. Customize most things about how things look/move in "/water gui"
8. Use shaders! There are shaders in this mod, but they are in beta. If you still wanna try them out: Video Settings -> Shader Packs, they work best on Vulkan 

IMPORTANT: Mods like Sodium, Iris or any other mod that hooks into the render, might not be 100% stable with this mod. This doesn't mean that they instant crash your game, just might some things will be weird.

If you wanna try the built in shaders out, DON'T use sodium

Showcase: https://www.youtube.com/watch?v=GG2-psEHUI4

#

Water pumps:

<img width="1920" height="1080" alt="Still 2026-10-24 125037_1 78 1" src="https://github.com/user-attachments/assets/0b443877-8610-4ed4-9aa7-7e3a6ae1f6ad" />


Everything else:

<img width="1280" height="720" alt="New Project - 2026-10-24T125259 436" src="https://github.com/user-attachments/assets/5559a179-8878-4f9e-a3c3-4126bc5fccd6" />


Credits: https://github.com/claude and https://github.com/eva-akselrad
